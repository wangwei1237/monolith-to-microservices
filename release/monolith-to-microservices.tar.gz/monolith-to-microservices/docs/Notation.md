air cover: 空中掩护
active maintenance: 主动维护
back pressure
bounded context: 界定的上下文
brownfield:
burning platform: 燃烧的平台
business analyst: 商业分析师
cargo cult: 货物崇拜
concorde fallacy: 协和式谬误
continuous delivery
cycle time: 
delivery contention: 交付冲突
elephant in the room: 显而易见而又没人愿意讨论的问题
end-to-end extraction: 端到端抽取
ESB(Enterprise Service Bus): 
implementation couples: 实现耦合
greenfield: 
management consultancy: 管理咨询公司
mix and match: 混搭 
multi-tenant: 多租户
back pressure: 
organizational-silos: 组织孤岛
project sponsor: 项目发起人
project owner: 产品负责人
referential integrity: 参照完整性
re-platform: 更换平台，也称为 “修补后迁移”
Re-Purchase: 重新购置，也称为 “放弃后购买”
Re-Host: 重新托管，也称为 “直接迁移”
Re-Architect: 重构/重新构建
Retire: 停用
Retain: 保留
Scale-ups: 规模企业
shallow extractions: 浅层抽取
silos: 孤岛
single-tenant: 单租户
smart endpoints, dumb pipes: 智能终端，傻瓜通道
stale data: 脏数据
stakeholder: 
startups: 初创企业
strangler fig approach: 绞杀者模式
sunk cost: 沉默成本
the Mythical Man Month: 人月神话
yawing chasm of mistrust: 不信任鸿沟